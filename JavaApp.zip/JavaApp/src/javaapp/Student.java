/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapp;

/**
 *
 * @author student
 */
public class Student extends Person {
    private long index;
    private double AvgGrade;
    private Major vocation;
    private short grades;
    private long indexNumerrator;

    public long getIndex() {
        return index;
    }

    public double getAvgGrade() {
        return AvgGrade;
    }

    public Major getVocation() {
        return vocation;
    }

    public short getGrades() {
        return grades;
    }
}


