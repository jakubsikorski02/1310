/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapp;

/**
 *
 * @author student
 */
public class Employee extends Person {
    private double salary;
    private Position occupation;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" + "Pracownik=" + name + ", Pensja=" + salary + ", Etat=" + occupation + '}';
    }
    
    public void promote(Position newPosition){
        this.occupation = newPosition;
    }


    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

}
